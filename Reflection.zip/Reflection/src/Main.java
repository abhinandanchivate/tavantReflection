import com.tavant.reflection.ConcreteClass;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Class<?> concreteClass = ConcreteClass.class;
		
		concreteClass = new ConcreteClass(5).getClass();
		System.out.println(concreteClass);
		System.out.println(ConcreteClass.class.getName());
		System.out.println(concreteClass.getName());
		
		for (Class string : concreteClass.getClasses()) {
			System.out.println(string);
		}
	}

}
