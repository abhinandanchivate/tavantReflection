import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.Arrays;
import java.util.HashMap;

import com.tavant.reflection.ConcreteClass;

public class MainSuper {

	public static void main(String[] args) {
//		Class<?> superClass = ConcreteClass.class.getSuperclass();
//		System.out.println(superClass);
//		// BaseClass
//		System.out.println(superClass.getSuperclass());
//		//Object
//		System.out.println(superClass.getSuperclass().getSuperclass());
//		// null
//		System.out.println(ConcreteClass.class.getPackageName());
//		System.out.println(ConcreteClass.class.getPackage());
//		System.out.println(ConcreteClass.class.getAnnotations());
//		System.out.println(Modifier.toString(ConcreteClass.class.getModifiers()));
//		
//		TypeVariable<?>[] typeVariables;
//		typeVariables = ConcreteClass.class.getTypeParameters();
//		System.out.println(typeVariables.length);
//		for (TypeVariable<?> typeVariable : typeVariables) {
//			System.out.println(typeVariable.getName());
//		}
		
//		Type[] types = ConcreteClass.class.getGenericInterfaces();
//		for (Type type : types) {
//			System.out.println(type);
//		}
		
		Method[] publicMethods = ConcreteClass.class.getMethods();
		
		for (Method method : publicMethods) {
			System.out.println(method);
		}
		
		
	}
}

// ConcreteClass====>BaseClass=====>Object
