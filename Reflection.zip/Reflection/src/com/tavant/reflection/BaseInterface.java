package com.tavant.reflection;

public interface BaseInterface {
public int interfaceInt=0;
	
	void method1();
	
	int method2(String str);
	
}
