import java.lang.reflect.Field;

import com.tavant.reflection.ConcreteClass;

public class MainPrivateSetGet {

	public static void main(String[] args) {
		Field field2;
		try {
			field2 = Class.forName(ConcreteClass.class.getName()).getDeclaredField("privateString");
			field2.setAccessible(true);
			Class<?> fieldType2 = field2.getType();
			System.out.println(fieldType2.getCanonicalName());
			System.out.println(field2.getName());
			ConcreteClass obj = new ConcreteClass(5);
			System.out.println(field2.get(obj));// to retrieve the publicInt value.
			
		} catch (NoSuchFieldException | SecurityException | ClassNotFoundException | IllegalArgumentException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
