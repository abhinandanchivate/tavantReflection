
public interface Animal {

	public void eat();
}
