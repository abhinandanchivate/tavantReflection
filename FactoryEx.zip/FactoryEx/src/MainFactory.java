
public class MainFactory {

	public static void main(String[] args) {
		
		Animal animal = new AnimalFactory().getAnimal("dog");
		System.out.println(animal instanceof Dog);
		Animal animal2 = new AnimalFactory().getAnimal("rabbit");
		System.out.println(animal2 instanceof Rabbit);
	}
}
